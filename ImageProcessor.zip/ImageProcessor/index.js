var AWS         = require('aws-sdk');
var ImageMagick = require('gm').subClass({ imageMagick: true });
var Promise     = require('bluebird');
var config      = require('./config.json');

var s3 = new AWS.S3();

exports.handler = function(event, context) {
  console.log(JSON.stringify(event));
  resizeImage(event).then(function(image) {
    console.log(image);
    context.succeed(image);
  }).catch(function(err) {
    console.log(err);
    context.fail(err);
  });
};

function getImageType(objectContentType) {
  if(objectContentType === 'image/jpeg') {
    return 'jpeg';
  } else if (objectContentType === 'image/png') {
    return 'png';
  } else {
    throw new Error('unsupported objectContentType ' + objectContentType);
  }
}

function cross(left, right) {
  var res = [];
  left.forEach(function(l) {
    right.forEach(function(r) {
      res.push([l, r]);
    });
  });
  return res;
}

function resizeImage(event) {
  return Promise.map(event.Records, function(record) {
    return getImage(record);
  }).then(function(images) {
    return Promise.each(cross(config.sizes, images), function(resizePair) {
      return resize(resizePair);
    });
  });
}

function resize(resizePair) {
  return new Promise(function(accept, reject) {
    var config = resizePair[0];
    var image = resizePair[1];
    ImageMagick(image.buffer).resize(config.dimensions.split('x')[0], config.dimensions.split('x')[1], '>').toBuffer(image.imageType, function(err, buffer) {
      if(err) {
        reject(err);
      } else {
        s3.putObject({
          Bucket: image.record.s3.bucket.name.replace('raw', 'processed'),
          Key: config.folder + '/' + image.originalKey,
          Body: buffer,
          ContentType: image.contentType,
          ACL: 'public-read'
        }, function(err, data) {
          if(err) {
            reject(err);
          } else {
            accept(data);
          }
        });
      }
    });
  });
}

function getImage(record) {
  var originalKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
  return new Promise(function (accept, reject) {
    s3.getObject({
      Bucket: record.s3.bucket.name,
      Key: originalKey
    }, function(err, data) {
      if (err) {
        reject(err);
      } else {
        accept({
          originalKey: originalKey,
          contentType: data.ContentType,
          imageType: getImageType(data.ContentType),
          buffer: data.Body,
          record: record
        });
      }
    });
  });
}